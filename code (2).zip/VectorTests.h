#ifndef HW3_TESTS_H
#define HW3_TESTS_H

void runVectorTests();

#endif //HW3_TESTS_H
