#include "VectorTests.h"

int main() {
    runVectorTests();
    return 0;
}